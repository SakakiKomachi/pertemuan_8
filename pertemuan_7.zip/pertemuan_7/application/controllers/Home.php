<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function index ()
    {
        $this->load->view('_partial/head');
        $this->load->view('page/Home');
        $this->load->view('_partial/footer');
        }
    
    public function about()
    {
        $this->load->view('_partial/head');
        $this->load->view('page/about');
        $this->load->view('_partial/footer');
    }
}