<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>Cara Kerja Library </title>
</head>
<body>
<CENTER>
<h1>INI BAGIAN HEADER</h1>
<a href="<?php echo base_url('index.php/welcome/index'); ?>">Menu 1</a> | <a href="<?php echo 
base_url('index.php/welcome/menu2'); ?>">Menu 2</a>
<hr>
<?= $contents; ?>
<hr>
<h1>INI BAGIAN FOOTER</h1>
</CENTER>
</body>
</html>
